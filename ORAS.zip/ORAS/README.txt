----------------------------------------------------------------------------
CTRPF Plugin for Luma3DS with Plugin Loader
----------------------------------------------------------------------------

Game: Pokémon ORAS (with Update)

Creators: H4x0rSpooky & FunkyGamer26

----------------------------------------------------------------------------

Github Website: https://github.com/H4x0rSpooky/PKMN-ORAS-Plugin

GBATemp Thread: - coming soon -

Make sure to report bugs or make suggestions

----------------------------------------------------------------------------

YouTube Channels
------------------------------

FunkyGamer26: https://www.youtube.com/channel/UCu_YHU4ZHWORABbD-aosqPg

H4x0rSpooky: https://www.youtube.com/channel/UC-SFdCwwq3H1wJNKCsKMGPw

----------------------------------------------------------------------------